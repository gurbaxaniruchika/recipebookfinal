# The Index — Recipe Book (React mini project)

Built on your `recipe-frontend-starter` (Vite 8 + React 19, `.jsx`, `tsc && vite build`),
styled entirely with plain CSS, using **react-router-dom** for routing and **react-icons**
for icons.

## Data source

All recipe data comes **only** from your local API — nothing is bundled locally:

```
Base URL: http://192.168.1.182/Recipe
```

| Method | Path                        | Used for                          |
|--------|-----------------------------|------------------------------------|
| GET    | `/recipes`                  | loading all recipes on Browse      |
| GET    | `/recipes/search?q=`        | available, not wired to UI yet     |
| GET    | `/recipes/tags`              | available, not wired to UI yet     |
| GET    | `/recipes/tag/{tag}`         | available, not wired to UI yet     |
| GET    | `/recipes/meal-type/{meal}`  | available, not wired to UI yet     |
| GET    | `/recipes/{id}`              | available, not wired to UI yet     |
| POST   | `/recipes/add`               | Add Recipe page                    |
| PUT    | `/recipes/{id}`              | Edit Recipe page                   |
| DELETE | `/recipes/{id}`              | Delete button in the recipe modal  |
| POST   | `/recipes/reset`             | available, not wired to UI yet     |

Search, cuisine/tag/meal-type filtering are currently done **client-side** on the full
list returned by `GET /recipes` (see `src/pages/Home.jsx`). The API also exposes
server-side search/filter endpoints (`/recipes/search`, `/recipes/tag/{tag}`,
`/recipes/meal-type/{meal}`) in `src/services/api.js` if you'd rather switch to
server-side filtering later — just ask and I'll wire it up.

Since your machine is on the local network and I'm not, I couldn't hit this API myself
to verify field names — the code assumes the same schema as your original notes
(`name`, `ingredients`, `instructions`, `prepTimeMinutes`, `cookTimeMinutes`, `servings`,
`difficulty`, `cuisine`, `caloriesPerServing`, `tags`, `image`, `rating`, `reviewCount`,
`mealType`). If your backend's actual field names differ, tell me what they are and I'll
adjust `src/context/RecipeContext.jsx`, `src/components/RecipeCard`, `RecipeModal`, and
`RecipeForm` to match.

## Getting started

```bash
npm install
npm run dev
```

Make sure `http://192.168.1.182/Recipe` is reachable from wherever you run this
(same network/VPN as the backend) — otherwise requests will fail and you'll see the
in-app error message.

## Build

```bash
npm run build   # runs tsc (JS-only, just checks there are no syntax errors) then vite build
npm run preview
```

> Note: `tsconfig.json` has `allowJs: true` added so `tsc` doesn't error with
> "No inputs were found" on a project with only `.jsx` files. It does not enforce
> type checking on the JS code — it's purely there so the existing `tsc && vite build`
> script in `package.json` still runs cleanly with plain JavaScript.

## Project structure

```
src/
├── assets/
├── components/
│   ├── Header/
│   ├── Filter/            search + cuisine/meal/tag dropdowns (client-side)
│   ├── RecipeCard/         index-card styled preview, in the grid
│   ├── RecipeModal/        full detail view (view/edit/delete)
│   ├── RecipeForm/         shared form used by Add & Edit pages
│   └── Loader/
├── pages/
│   ├── Home.jsx            browse + search + filter
│   ├── Favorites.jsx
│   ├── AddRecipe.jsx
│   └── EditRecipe.jsx
├── context/
│   └── RecipeContext.jsx   global state: recipes (fetched from your API), favorites, CRUD
├── services/
│   └── api.js               all axios calls to http://192.168.1.182/Recipe
├── styles/
│   └── global.css           design tokens + base styles
├── App.jsx
└── main.jsx
```
