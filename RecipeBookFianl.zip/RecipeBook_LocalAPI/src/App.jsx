import { Routes, Route } from "react-router-dom";
import { RecipeProvider } from "./context/RecipeContext";
import Header from "./components/Header/Header";
import Home from "./pages/Home";
import Favorites from "./pages/Favorites";
import AddRecipe from "./pages/AddRecipe";
import EditRecipe from "./pages/EditRecipe";

export default function App() {
  return (
    <RecipeProvider>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/favorites" element={<Favorites />} />
        <Route path="/add" element={<AddRecipe />} />
        <Route path="/edit/:id" element={<EditRecipe />} />
      </Routes>
    </RecipeProvider>
  );
}
