import { FiSearch, FiX } from "react-icons/fi";
import "./Filter.css";

export default function Filter({
  search,
  onSearchChange,
  cuisine,
  onCuisineChange,
  cuisines,
  mealType,
  onMealTypeChange,
  mealTypes,
  tag,
  onTagChange,
  tags,
  onReset,
  resultCount,
}) {
  const hasActiveFilters = search || cuisine || mealType || tag;

  return (
    <div className="filter-bar">
      <div className="filter-bar__search">
        <FiSearch className="filter-bar__search-icon" />
        <input
          type="text"
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Search recipes, e.g. 'pizza' or 'tofu'..."
          aria-label="Search recipes"
        />
        {search && (
          <button
            type="button"
            className="filter-bar__clear"
            onClick={() => onSearchChange("")}
            aria-label="Clear search"
          >
            <FiX />
          </button>
        )}
      </div>

      <div className="filter-bar__selects">
        <select value={cuisine} onChange={(e) => onCuisineChange(e.target.value)} aria-label="Filter by cuisine">
          <option value="">All cuisines</option>
          {cuisines.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>

        <select value={mealType} onChange={(e) => onMealTypeChange(e.target.value)} aria-label="Filter by meal type">
          <option value="">Any meal</option>
          {mealTypes.map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </select>

        <select value={tag} onChange={(e) => onTagChange(e.target.value)} aria-label="Filter by tag">
          <option value="">Any tag</option>
          {tags.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>

        {hasActiveFilters && (
          <button type="button" className="filter-bar__reset" onClick={onReset}>
            Clear filters
          </button>
        )}
      </div>

      <div className="filter-bar__count eyebrow">
        {resultCount} {resultCount === 1 ? "recipe" : "recipes"} found
      </div>
    </div>
  );
}
