import { NavLink } from "react-router-dom";
import { FiBookOpen, FiHeart, FiPlusCircle } from "react-icons/fi";
import { useRecipes } from "../../context/RecipeContext";
import "./Header.css";

export default function Header() {
  const { favorites } = useRecipes();

  return (
    <header className="app-header">
      <div className="container app-header__inner">
        <NavLink to="/" className="brand">
          <span className="brand__mark">
            <FiBookOpen />
          </span>
          <span className="brand__text">
            <span className="brand__title">The Index</span>
            <span className="brand__subtitle">a recipe box</span>
          </span>
        </NavLink>

        <nav className="app-nav">
          <NavLink
            to="/"
            end
            className={({ isActive }) => "app-nav__link" + (isActive ? " is-active" : "")}
          >
            Browse
          </NavLink>
          <NavLink
            to="/favorites"
            className={({ isActive }) => "app-nav__link" + (isActive ? " is-active" : "")}
          >
            <FiHeart className="app-nav__icon" />
            Favorites
            {favorites.length > 0 && (
              <span className="app-nav__badge">{favorites.length}</span>
            )}
          </NavLink>
          <NavLink
            to="/add"
            className={({ isActive }) => "app-nav__link app-nav__link--cta" + (isActive ? " is-active" : "")}
          >
            <FiPlusCircle className="app-nav__icon" />
            Add recipe
          </NavLink>
        </nav>
      </div>
    </header>
  );
}
