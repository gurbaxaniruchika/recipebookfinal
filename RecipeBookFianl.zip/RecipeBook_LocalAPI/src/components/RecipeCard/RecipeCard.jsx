import { FiHeart, FiStar, FiClock } from "react-icons/fi";
import { useRecipes } from "../../context/RecipeContext";
import "./RecipeCard.css";

const DIFFICULTY_DOTS = { Easy: 1, Medium: 2, Hard: 3 };

export default function RecipeCard({ recipe, onOpen }) {
  const { favorites, toggleFavorite } = useRecipes();
  const isFavorite = favorites.includes(recipe.id);
  const dots = DIFFICULTY_DOTS[recipe.difficulty] || 1;
  const totalTime = (recipe.prepTimeMinutes || 0) + (recipe.cookTimeMinutes || 0);

  return (
    <article className="recipe-card">
      <button
        type="button"
        className={"recipe-card__fav" + (isFavorite ? " is-active" : "")}
        onClick={(e) => {
          e.stopPropagation();
          toggleFavorite(recipe.id);
        }}
        aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
      >
        <FiHeart />
      </button>

      <button type="button" className="recipe-card__media" onClick={() => onOpen(recipe)}>
        <img src={recipe.image} alt={recipe.name} loading="lazy" />
        <span className="recipe-card__cuisine">{recipe.cuisine}</span>
      </button>

      <div className="recipe-card__body" onClick={() => onOpen(recipe)}>
        <h3 className="recipe-card__title">{recipe.name}</h3>

        <div className="recipe-card__meta">
          <span className="recipe-card__meta-item">
            <FiClock /> {totalTime} min
          </span>
          <span className="recipe-card__meta-item">
            <FiStar /> {recipe.rating?.toFixed(1)}
          </span>
          <span className="recipe-card__dots" title={recipe.difficulty}>
            {[1, 2, 3].map((i) => (
              <i key={i} className={i <= dots ? "is-filled" : ""} />
            ))}
          </span>
        </div>

        <div className="recipe-card__tags">
          {(recipe.mealType || []).slice(0, 2).map((m) => (
            <span key={m} className="chip chip--herb">
              {m}
            </span>
          ))}
          {(recipe.tags || []).slice(0, 2).map((t) => (
            <span key={t} className="chip">
              {t}
            </span>
          ))}
        </div>
      </div>
    </article>
  );
}
