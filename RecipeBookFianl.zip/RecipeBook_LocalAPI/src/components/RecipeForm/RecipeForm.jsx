import { useState } from "react";
import "./RecipeForm.css";

const DIFFICULTIES = ["Easy", "Medium", "Hard"];
const MEAL_TYPES = ["Breakfast", "Lunch", "Dinner", "Snack", "Dessert"];

const emptyForm = {
  name: "",
  image: "",
  cuisine: "",
  difficulty: "Easy",
  prepTimeMinutes: "",
  cookTimeMinutes: "",
  servings: "",
  caloriesPerServing: "",
  ingredients: "",
  instructions: "",
  tags: "",
  mealType: [],
};

function recipeToForm(recipe) {
  if (!recipe) return emptyForm;
  return {
    name: recipe.name || "",
    image: recipe.image || "",
    cuisine: recipe.cuisine || "",
    difficulty: recipe.difficulty || "Easy",
    prepTimeMinutes: recipe.prepTimeMinutes ?? "",
    cookTimeMinutes: recipe.cookTimeMinutes ?? "",
    servings: recipe.servings ?? "",
    caloriesPerServing: recipe.caloriesPerServing ?? "",
    ingredients: (recipe.ingredients || []).join("\n"),
    instructions: (recipe.instructions || []).join("\n"),
    tags: (recipe.tags || []).join(", "),
    mealType: recipe.mealType || [],
  };
}

export default function RecipeForm({ initialRecipe, onSubmit, submitLabel = "Save recipe" }) {
  const [form, setForm] = useState(() => recipeToForm(initialRecipe));
  const [errors, setErrors] = useState({});

  const update = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  const toggleMealType = (meal) => {
    setForm((prev) => ({
      ...prev,
      mealType: prev.mealType.includes(meal)
        ? prev.mealType.filter((m) => m !== meal)
        : [...prev.mealType, meal],
    }));
  };

  const validate = () => {
    const next = {};
    if (!form.name.trim()) next.name = "Give your recipe a name.";
    if (!form.ingredients.trim()) next.ingredients = "Add at least one ingredient.";
    if (!form.instructions.trim()) next.instructions = "Add at least one step.";
    if (!form.cuisine.trim()) next.cuisine = "Add a cuisine.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    const payload = {
      name: form.name.trim(),
      image: form.image.trim() || "https://cdn.dummyjson.com/recipe-images/1.webp",
      cuisine: form.cuisine.trim(),
      difficulty: form.difficulty,
      prepTimeMinutes: Number(form.prepTimeMinutes) || 0,
      cookTimeMinutes: Number(form.cookTimeMinutes) || 0,
      servings: Number(form.servings) || 1,
      caloriesPerServing: Number(form.caloriesPerServing) || 0,
      ingredients: form.ingredients.split("\n").map((s) => s.trim()).filter(Boolean),
      instructions: form.instructions.split("\n").map((s) => s.trim()).filter(Boolean),
      tags: form.tags.split(",").map((s) => s.trim()).filter(Boolean),
      mealType: form.mealType.length ? form.mealType : ["Dinner"],
    };

    onSubmit(payload);
  };

  return (
    <form className="recipe-form" onSubmit={handleSubmit} noValidate>
      <div className="recipe-form__grid">
        <label className="field field--full">
          <span>Recipe name</span>
          <input
            type="text"
            value={form.name}
            onChange={(e) => update("name", e.target.value)}
            placeholder="Classic Margherita Pizza"
          />
          {errors.name && <em className="field__error">{errors.name}</em>}
        </label>

        <label className="field field--full">
          <span>Image URL</span>
          <input
            type="text"
            value={form.image}
            onChange={(e) => update("image", e.target.value)}
            placeholder="https://..."
          />
        </label>

        <label className="field">
          <span>Cuisine</span>
          <input
            type="text"
            value={form.cuisine}
            onChange={(e) => update("cuisine", e.target.value)}
            placeholder="Italian"
          />
          {errors.cuisine && <em className="field__error">{errors.cuisine}</em>}
        </label>

        <label className="field">
          <span>Difficulty</span>
          <select value={form.difficulty} onChange={(e) => update("difficulty", e.target.value)}>
            {DIFFICULTIES.map((d) => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>
        </label>

        <label className="field">
          <span>Prep time (min)</span>
          <input
            type="number"
            min="0"
            value={form.prepTimeMinutes}
            onChange={(e) => update("prepTimeMinutes", e.target.value)}
          />
        </label>

        <label className="field">
          <span>Cook time (min)</span>
          <input
            type="number"
            min="0"
            value={form.cookTimeMinutes}
            onChange={(e) => update("cookTimeMinutes", e.target.value)}
          />
        </label>

        <label className="field">
          <span>Servings</span>
          <input
            type="number"
            min="1"
            value={form.servings}
            onChange={(e) => update("servings", e.target.value)}
          />
        </label>

        <label className="field">
          <span>Calories / serving</span>
          <input
            type="number"
            min="0"
            value={form.caloriesPerServing}
            onChange={(e) => update("caloriesPerServing", e.target.value)}
          />
        </label>

        <label className="field field--full">
          <span>Ingredients (one per line)</span>
          <textarea
            rows={5}
            value={form.ingredients}
            onChange={(e) => update("ingredients", e.target.value)}
            placeholder={"Pizza dough\nTomato sauce\nFresh mozzarella"}
          />
          {errors.ingredients && <em className="field__error">{errors.ingredients}</em>}
        </label>

        <label className="field field--full">
          <span>Instructions (one step per line)</span>
          <textarea
            rows={6}
            value={form.instructions}
            onChange={(e) => update("instructions", e.target.value)}
            placeholder={"Preheat the oven to 475°F.\nRoll out the dough..."}
          />
          {errors.instructions && <em className="field__error">{errors.instructions}</em>}
        </label>

        <label className="field field--full">
          <span>Tags (comma separated)</span>
          <input
            type="text"
            value={form.tags}
            onChange={(e) => update("tags", e.target.value)}
            placeholder="Pizza, Italian, Vegetarian"
          />
        </label>

        <div className="field field--full">
          <span>Meal type</span>
          <div className="recipe-form__meal-types">
            {MEAL_TYPES.map((meal) => (
              <button
                type="button"
                key={meal}
                className={"chip chip--toggle" + (form.mealType.includes(meal) ? " is-selected" : "")}
                onClick={() => toggleMealType(meal)}
              >
                {meal}
              </button>
            ))}
          </div>
        </div>
      </div>

      <button type="submit" className="btn btn-primary recipe-form__submit">
        {submitLabel}
      </button>
    </form>
  );
}
