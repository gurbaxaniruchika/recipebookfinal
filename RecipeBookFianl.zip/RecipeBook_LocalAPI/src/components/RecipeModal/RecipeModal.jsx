import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { FiX, FiHeart, FiStar, FiClock, FiUsers, FiEdit2, FiTrash2 } from "react-icons/fi";
import { useRecipes } from "../../context/RecipeContext";
import "./RecipeModal.css";

export default function RecipeModal({ recipe, onClose }) {
  const { favorites, toggleFavorite, deleteRecipe } = useRecipes();
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const navigate = useNavigate();
  const isFavorite = favorites.includes(recipe.id);

  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  const handleDelete = async () => {
    await deleteRecipe(recipe.id);
    onClose();
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <button type="button" className="modal-card__close" onClick={onClose} aria-label="Close">
          <FiX />
        </button>

        <div className="modal-card__media">
          <img src={recipe.image} alt={recipe.name} />
          <span className="modal-card__cuisine">{recipe.cuisine}</span>
        </div>

        <div className="modal-card__body">
          <div className="modal-card__heading">
            <h2>{recipe.name}</h2>
            <button
              type="button"
              className={"modal-card__fav" + (isFavorite ? " is-active" : "")}
              onClick={() => toggleFavorite(recipe.id)}
              aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
            >
              <FiHeart />
            </button>
          </div>

          <div className="modal-card__stats">
            <span>
              <FiClock /> {recipe.prepTimeMinutes} prep + {recipe.cookTimeMinutes} cook min
            </span>
            <span>
              <FiUsers /> Serves {recipe.servings}
            </span>
            <span>
              <FiStar /> {recipe.rating?.toFixed(1)} ({recipe.reviewCount} reviews)
            </span>
            <span className="modal-card__difficulty">{recipe.difficulty}</span>
          </div>

          <div className="modal-card__tags">
            {(recipe.mealType || []).map((m) => (
              <span key={m} className="chip chip--herb">{m}</span>
            ))}
            {(recipe.tags || []).map((t) => (
              <span key={t} className="chip">{t}</span>
            ))}
          </div>

          <div className="modal-card__columns">
            <section>
              <h4 className="eyebrow">Ingredients</h4>
              <ul className="modal-card__ingredients">
                {(recipe.ingredients || []).map((ing, i) => (
                  <li key={i}>{ing}</li>
                ))}
              </ul>
            </section>

            <section>
              <h4 className="eyebrow">Instructions</h4>
              <ol className="modal-card__instructions">
                {(recipe.instructions || []).map((step, i) => (
                  <li key={i}>{step}</li>
                ))}
              </ol>
            </section>
          </div>

          <div className="modal-card__footer">
            <span className="modal-card__calories eyebrow">
              {recipe.caloriesPerServing} kcal / serving
            </span>
            <div className="modal-card__actions">
              <button
                type="button"
                className="btn btn-ghost"
                onClick={() => navigate(`/edit/${recipe.id}`)}
              >
                <FiEdit2 /> Edit
              </button>
              {!confirmingDelete ? (
                <button
                  type="button"
                  className="btn btn-danger"
                  onClick={() => setConfirmingDelete(true)}
                >
                  <FiTrash2 /> Delete
                </button>
              ) : (
                <span className="modal-card__confirm">
                  Delete this recipe?
                  <button type="button" className="btn btn-danger" onClick={handleDelete}>
                    Yes, delete
                  </button>
                  <button type="button" className="btn btn-ghost" onClick={() => setConfirmingDelete(false)}>
                    Cancel
                  </button>
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
