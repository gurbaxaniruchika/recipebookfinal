import { createContext, useContext, useState, useEffect, useCallback } from "react";
import {
  fetchAllRecipes,
  addRecipeApi,
  updateRecipeApi,
  deleteRecipeApi,
} from "../services/api";

const RecipeContext = createContext(null);

const FAVORITES_KEY = "recipebook:favorites";

function readJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

export function RecipeProvider({ children }) {
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [favorites, setFavorites] = useState(() => readJSON(FAVORITES_KEY, []));

  const loadRecipes = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchAllRecipes();
      setRecipes(res.data.recipes || []);
    } catch (err) {
      setError("Couldn't reach the recipe API. Please check your connection and try again.");
      setRecipes([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadRecipes();
  }, [loadRecipes]);

  const nextId = (list) => (list.length ? Math.max(...list.map((r) => r.id)) : 0) + 1;

  // Note: DummyJSON's write endpoints only simulate a response and don't
  // persist server-side, so successful add/edit/delete calls are mirrored
  // into local state so the UI reflects the change for the rest of the session.
  const addRecipe = async (recipeData) => {
    let apiData = {};
    try {
      const res = await addRecipeApi(recipeData);
      apiData = res.data || {};
    } catch {
      // API write is only simulated by DummyJSON anyway — fall back to a local id
      // so the recipe still gets added for this session.
    }
    const newRecipe = {
      rating: 0,
      reviewCount: 0,
      ...recipeData,
      ...apiData,
      id: apiData.id ?? nextId(recipes),
    };
    setRecipes((prev) => [newRecipe, ...prev]);
    return newRecipe;
  };

  const updateRecipe = async (id, recipeData) => {
    try {
      await updateRecipeApi(id, recipeData);
    } catch {
      // Simulated endpoint — reflect the edit locally regardless.
    }
    setRecipes((prev) => prev.map((r) => (r.id === id ? { ...r, ...recipeData, id } : r)));
  };

  const deleteRecipe = async (id) => {
    try {
      await deleteRecipeApi(id);
    } catch {
      // Simulated endpoint — reflect the deletion locally regardless.
    }
    setRecipes((prev) => prev.filter((r) => r.id !== id));
    setFavorites((prev) => {
      const updated = prev.filter((fid) => fid !== id);
      localStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
      return updated;
    });
  };

  const toggleFavorite = (id) => {
    setFavorites((prev) => {
      const updated = prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id];
      localStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
      return updated;
    });
  };

  const getRecipeById = (id) => recipes.find((r) => String(r.id) === String(id));

  const value = {
    recipes,
    loading,
    error,
    favorites,
    toggleFavorite,
    addRecipe,
    updateRecipe,
    deleteRecipe,
    getRecipeById,
    refetch: loadRecipes,
  };

  return <RecipeContext.Provider value={value}>{children}</RecipeContext.Provider>;
}

export function useRecipes() {
  const ctx = useContext(RecipeContext);
  if (!ctx) throw new Error("useRecipes must be used inside a RecipeProvider");
  return ctx;
}
