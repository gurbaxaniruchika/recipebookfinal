import { useNavigate } from "react-router-dom";
import { useRecipes } from "../context/RecipeContext";
import RecipeForm from "../components/RecipeForm/RecipeForm";
import "./FormPage.css";

export default function AddRecipe() {
  const { addRecipe } = useRecipes();
  const navigate = useNavigate();

  const handleSubmit = async (payload) => {
    const created = await addRecipe(payload);
    navigate(`/`, { state: { justAddedId: created.id } });
  };

  return (
    <div className="page">
      <div className="container form-page">
        <div className="page-hero">
          <span className="eyebrow">New index card</span>
          <h1>Add a recipe</h1>
          <p className="page-hero__sub">
            File a new recipe into the box. It'll show up on the Browse page right away.
          </p>
        </div>
        <RecipeForm onSubmit={handleSubmit} submitLabel="Add to the box" />
      </div>
    </div>
  );
}
