import { useParams, useNavigate, Link } from "react-router-dom";
import { useRecipes } from "../context/RecipeContext";
import RecipeForm from "../components/RecipeForm/RecipeForm";
import "./FormPage.css";

export default function EditRecipe() {
  const { id } = useParams();
  const { getRecipeById, updateRecipe } = useRecipes();
  const navigate = useNavigate();
  const recipe = getRecipeById(id);

  const handleSubmit = async (payload) => {
    await updateRecipe(recipe.id, payload);
    navigate(`/`);
  };

  if (!recipe) {
    return (
      <div className="page">
        <div className="container">
          <div className="empty-state">
            <h3>Recipe not found</h3>
            <p>
              It may have been deleted already. <Link to="/">Back to Browse →</Link>
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="container form-page">
        <div className="page-hero">
          <span className="eyebrow">Editing</span>
          <h1>{recipe.name}</h1>
          <p className="page-hero__sub">Update the details below and save your changes.</p>
        </div>
        <RecipeForm initialRecipe={recipe} onSubmit={handleSubmit} submitLabel="Save changes" />
      </div>
    </div>
  );
}
