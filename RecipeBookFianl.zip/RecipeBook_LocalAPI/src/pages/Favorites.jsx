import { useState } from "react";
import { Link } from "react-router-dom";
import { useRecipes } from "../context/RecipeContext";
import RecipeCard from "../components/RecipeCard/RecipeCard";
import RecipeModal from "../components/RecipeModal/RecipeModal";
import Loader from "../components/Loader/Loader";
import "./Home.css";

export default function Favorites() {
  const { recipes, favorites, loading } = useRecipes();
  const [activeRecipe, setActiveRecipe] = useState(null);
  const favoriteRecipes = recipes.filter((r) => favorites.includes(r.id));

  return (
    <div className="page">
      <div className="container">
        <div className="page-hero">
          <span className="eyebrow">Dog-eared &amp; saved</span>
          <h1>Your favorites</h1>
          <p className="page-hero__sub">
            Every recipe you've tucked a bookmark into lives here.
          </p>
        </div>

        {loading ? (
          <Loader label="Fetching recipes..." />
        ) : favoriteRecipes.length === 0 ? (
          <div className="empty-state">
            <h3>No favorites yet</h3>
            <p>
              Tap the heart on any recipe to save it here. <Link to="/">Browse recipes →</Link>
            </p>
          </div>
        ) : (
          <div className="recipe-grid">
            {favoriteRecipes.map((recipe) => (
              <RecipeCard key={recipe.id} recipe={recipe} onOpen={setActiveRecipe} />
            ))}
          </div>
        )}
      </div>

      {activeRecipe && (
        <RecipeModal recipe={activeRecipe} onClose={() => setActiveRecipe(null)} />
      )}
    </div>
  );
}
