import { useMemo, useState } from "react";
import { useRecipes } from "../context/RecipeContext";
import Filter from "../components/Filter/Filter";
import RecipeCard from "../components/RecipeCard/RecipeCard";
import RecipeModal from "../components/RecipeModal/RecipeModal";
import Loader from "../components/Loader/Loader";
import "./Home.css";

export default function Home() {
  const { recipes, loading, error } = useRecipes();
  const [search, setSearch] = useState("");
  const [cuisine, setCuisine] = useState("");
  const [mealType, setMealType] = useState("");
  const [tag, setTag] = useState("");
  const [activeRecipe, setActiveRecipe] = useState(null);

  const { cuisines, mealTypes, tags } = useMemo(() => {
    const cuisineSet = new Set();
    const mealSet = new Set();
    const tagSet = new Set();
    recipes.forEach((r) => {
      if (r.cuisine) cuisineSet.add(r.cuisine);
      (r.mealType || []).forEach((m) => mealSet.add(m));
      (r.tags || []).forEach((t) => tagSet.add(t));
    });
    return {
      cuisines: [...cuisineSet].sort(),
      mealTypes: [...mealSet].sort(),
      tags: [...tagSet].sort(),
    };
  }, [recipes]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return recipes.filter((r) => {
      if (q && !r.name.toLowerCase().includes(q)) return false;
      if (cuisine && r.cuisine !== cuisine) return false;
      if (mealType && !(r.mealType || []).includes(mealType)) return false;
      if (tag && !(r.tags || []).includes(tag)) return false;
      return true;
    });
  }, [recipes, search, cuisine, mealType, tag]);

  const resetFilters = () => {
    setSearch("");
    setCuisine("");
    setMealType("");
    setTag("");
  };

  return (
    <div className="page">
      <div className="container">
        <div className="page-hero">
          <span className="eyebrow">The Index · a recipe box</span>
          <h1>What are we cooking today?</h1>
          <p className="page-hero__sub">
            Browse, search and file away recipes like index cards — pull one out, tweak it,
            or add your own to the box.
          </p>
        </div>

        <Filter
          search={search}
          onSearchChange={setSearch}
          cuisine={cuisine}
          onCuisineChange={setCuisine}
          cuisines={cuisines}
          mealType={mealType}
          onMealTypeChange={setMealType}
          mealTypes={mealTypes}
          tag={tag}
          onTagChange={setTag}
          tags={tags}
          onReset={resetFilters}
          resultCount={filtered.length}
        />

        {error && <p className="page-error">{error}</p>}

        {loading ? (
          <Loader label="Fetching recipes..." />
        ) : filtered.length === 0 ? (
          <div className="empty-state">
            <h3>No recipes match that search</h3>
            <p>Try a different keyword or clear your filters.</p>
          </div>
        ) : (
          <div className="recipe-grid">
            {filtered.map((recipe) => (
              <RecipeCard key={recipe.id} recipe={recipe} onOpen={setActiveRecipe} />
            ))}
          </div>
        )}
      </div>

      {activeRecipe && (
        <RecipeModal recipe={activeRecipe} onClose={() => setActiveRecipe(null)} />
      )}
    </div>
  );
}
