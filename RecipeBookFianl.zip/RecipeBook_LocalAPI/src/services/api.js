import axios from "axios";

// Base URL for the recipe backend (local network / Swagger-documented API).
// Swagger docs: http://192.168.1.182/Recipe/Swagger/index.html
const BASE_URL = "http://192.168.1.182/Recipe";

const client = axios.create({ baseURL: BASE_URL, timeout: 8000 });

/** GET /recipes  (all recipes; limit=0 asks the API for the full list) */
export const fetchAllRecipes = () =>
  client.get("/recipes", { params: { limit: 0, skip: 0, order: "asc" } });

/** GET /recipes/search?q= */
export const searchRecipesApi = (q) =>
  client.get("/recipes/search", { params: { q, limit: 30, skip: 0 } });

/** GET /recipes/tags */
export const fetchTagsApi = () => client.get("/recipes/tags");

/** GET /recipes/tag/{tag} */
export const fetchByTagApi = (tag) => client.get(`/recipes/tag/${tag}`);

/** GET /recipes/meal-type/{meal} */
export const fetchByMealTypeApi = (meal) =>
  client.get(`/recipes/meal-type/${meal}`);

/** GET /recipes/{id} */
export const fetchRecipeByIdApi = (id) => client.get(`/recipes/${id}`);

/** POST /recipes/add */
export const addRecipeApi = (recipe) => client.post("/recipes/add", recipe);

/** PUT /recipes/{id} */
export const updateRecipeApi = (id, recipe) =>
  client.put(`/recipes/${id}`, recipe);

/** DELETE /recipes/{id} */
export const deleteRecipeApi = (id) => client.delete(`/recipes/${id}`);

/** POST /recipes/reset — restores the backend's original seed data. */
export const resetRecipesApi = () => client.post("/recipes/reset");
